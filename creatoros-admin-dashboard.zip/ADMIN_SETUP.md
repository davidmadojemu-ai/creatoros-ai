# CreatorOS AI — Admin Dashboard Setup

## What was added
- `/admin` → private admin dashboard (`admin/index.html`)
- Homepage and existing waitlist files are **unchanged**

## 1. Upload to GitHub
Upload the `admin` folder into your repo root:

```
creatoros-ai/
  index.html          (keep)
  waitlist.html       (keep)
  legal.html          (keep)
  vercel.json         (keep)
  og-image.png        (keep)
  admin/
    index.html        ← new
```

After deploy, open: **https://creatorosai-phi.vercel.app/admin**

## 2. Create the admin user in Supabase
1. Open your Supabase project → **Authentication** → **Users**
2. Click **Add user** → **Create new user**
3. Email: `creatorosaisupport@gmail.com`
4. Set a strong password (you will use this to sign in)
5. Confirm / auto-confirm the user

## 3. Allow the admin to read the waitlist (RLS)
In Supabase → **SQL Editor**, run:

```sql
-- Enable RLS if not already
ALTER TABLE waitlist ENABLE ROW LEVEL SECURITY;

-- Keep public INSERT for the waitlist form (anon can join)
-- (You may already have this policy — skip if it exists)

-- Allow authenticated admin to SELECT all rows
CREATE POLICY "Admin can read waitlist"
ON waitlist
FOR SELECT
TO authenticated
USING (
  auth.jwt() ->> 'email' = 'creatorosaisupport@gmail.com'
);
```

If you already have a SELECT policy for anon/authenticated, adjust as needed so only the admin email can read.

Optional — ensure `created_at` exists:

```sql
ALTER TABLE waitlist
ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
```

## 4. Sign in
1. Go to `/admin`
2. Email: `creatorosaisupport@gmail.com`
3. Password: the one you set in Supabase Auth

## Notes
- Only that email is allowed (hard-checked in the admin page)
- Revenue shows `$0.00` until you connect payments
- Visitor analytics stay as placeholders until Vercel Analytics API is wired
- No service-role key is stored in the repo
